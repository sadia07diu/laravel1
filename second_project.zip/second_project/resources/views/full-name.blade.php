<h1>
    <?php echo $firstName; ?>
    {{ $lastName }}
    {{ $firstName }}
</h1>
<h2>
    second - {{ $firstName." ".$lastName }}
</h2>
