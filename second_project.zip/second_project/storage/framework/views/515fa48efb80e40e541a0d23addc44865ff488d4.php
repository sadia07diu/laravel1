<h1>
    <?php echo $firstName; ?>
    <?php echo e($lastName); ?>

    <?php echo e($firstName); ?>

</h1>
<h2>
    second - <?php echo e($firstName." ".$lastName); ?>

</h2>
<?php /**PATH C:\xampp\htdocs\second_project\resources\views/full-name.blade.php ENDPATH**/ ?>